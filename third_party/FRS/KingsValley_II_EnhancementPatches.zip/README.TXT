King's Valley II, The Seal of El Giza enhancement patches
---------------------------------------------------------
v1.1 (c) 2011 by FRS, all rights reserved

1) This patch implements the Dynamic Vsync timing routines on the game, greatly
reducing slowdowns on Z80A machines and allowing the game to be run on with the
turbo enabled on machines that have this feature. The turbo will be enabled by
default on any machine that has the standard CHGCPU routine on its BIOS (like
MSX Turbo-R machines).

2) The patch will also implements the following enhancements and fixes:

2.1) On MSX1, MSX2 and MSX2-Gold versions:

- Hold TAB to throttle the game speed
- Automatically sets the VDP to 60Hz on boot, to play the game at the correct
  speed even on european machines. If you have an old european TV that doesn't
  support this, keep SELECT pressed on boot to disable it.
- Enhanced sprite cycling: if you have a turbo machine, the sprite cycling
  routine will now take advantage of that and the flickering of the sprites will
  occur at a higher framerate, dynamically adjusted as high as your CPU
  supports.
- Many small optimizations on the jukebox, reducing the CPU usage
- Pausing the game don't stop the sprite flickering anymore

2.2) Specific bugfixes/enhancements for each version:

- KV21/KV22: Now both coldboot and warmboot are supported. This means that the
  ROM not only boots as a cartridge, but also detects if it was booted from
  MSX-DOS and boots correctly with disk support on both cases. This allow you
  to load the games under the MSX-DOS2 using your favorite ROM loader and use
  the harddisk for loading/saving custom stages.
- KV21/KV22: Finally it's possible to set the desired theme for a stage. The
  6 original themes are supported and 2 "new" themes (see below) are supported,
  which along with the second palette supported for each theme supported by the
  KV22 version results in 32 different possibilities.
  Se how to set this on the KV2STAGE.COM tool description above.
- KV22: Two "new" themes were created by combining two of the themes with the
  palette of each other.
- KV21/KV22: Fixed the bug that allowed files with spaces on its name to be
  saved on disk. This resulted in files that could no be handled properly by
  the MSX-DOS. The spaces on the filename are now replaced with underlines. The
  stage title will continue to be shown with spaces.
- KV22: Translated the introscreen logo
- KV2G: Translated the introscreen logo, certificate screen and the menus
- KV22/KV2G: Much faster routine for picking a tool/weapon. But 128KB of VRAM is
  now a requirement.
- KV22/KV2G: Smarter routine for refreshing objects on screen. It's much faster   and the objects don't flicker anymore
- KV21: On the 5th theme, the decorative beetle eyes now blink at the right
  place.
- KV21: Fixed the disk routines, now harddisks are supported for loading/saving
  stages (KV22 didn't had this bug and supported harddisks from the beginning)
- KV21: Removed GameMaster-1 compatibility, because it caused problems on
  harddisk support. GameMaster-2 compatibility is still present.
- KV21: Fixed the bug that caused the player sprite to appear on the wrong side
  of the screen for 1 frame on screen changes.
- KV21: The TMS9918 palette is loaded on MSX>=2 machines. I decided to use this
  palette instead of CoolColors because there's already an MSX2 version of the
  game. So the TMS9918 palette would be more faithful for comparisons between
  the two versions.
- KV22/KV2G: Modified to use the HKEYI hook instead of HTIMI, just like any
  other Konami game.
- KV22/KV2G: Relocated a variable that was placed on the HTIMI hook

2.3) The KV2STAGE.COM tool

This new tool was created to allow you to:

- Set the title of a stage
- Set the theme of a stage

For instructions on how to use this tool, use KV2STAGE /? under MSX-DOS.

3) Testing stages included

The following stages were included so you can compare the differences
on the patched games with the original ones, with and without the turbo, and
see other bugs that are still left in the game. Those stages were not meant to
be real puzzles, they were only created for testing purposes.

TST1SPD.ELG, aka "Lotsa Enemies".
TST2TOOL.ELG, aka "Lotsa Tools"
TST3SCR.ELG, aka "Screen change & aligned sprites"
TST4SPR.ELG, aka "Sprite flickering"
TST5DISA.ELG, aka "Disapearing objects" (shows many unfixed bugs of the game)




How to apply the patch
-----------------------

First, make sure you have the original japanese ROMs, which has the following
checksums:
SHA1(KVAL21.ROM)= cfd872d005b7bd4cdd6e06c4c0162191f0b0415d
SHA1(KVAL22.ROM)= 5ec8811254dc762c6852289a08acf22954404f0d
SHA1(KVAL2G.ROM)= 2e0436303648097e8e936c5467574aff5e3f1517

You can use the following tools to verify the SHA1 checksum:
- Windows:
  -MD5 & SHA-1 Checksum Utility 1.1
  - HashTab
- Mac OS-X:
  - DropHash
  - HashTab
  - (or use the Linux solution below)
- Linux:
  - Just type "openssl dgst -sha1 MYGAME.ROM" on a shell (without the quotes,
    off course).

- For applying the IPS patch, select an IPS patcher like IPSWin, LunarIPS or
  UIPS and use it following to the tool instructions.

- This set of patches has no XPC version, because the MSX2 versions got bigger 
  than the XPC specification allows.

==============================

Special Thanks

- Testing: Ant0niutti, snakepow
- Translation: Jazzin, BiFi, Vampier, pegase, Metalion, iamweasel2
- Logo design: SLotman, pegase
- BCD routines for the KV2STAGE tool: caro, bora
- OpenMSX team, for their excellent emulator and debugger
- MRC crew, for the place where MSX hobbysts can meet and exchange ideas
- Sjoerd Mastijn and Aprisobal, for the SjASMPlus assembler
- FiXato, for compiling XPCTools for Mac OS-X

==============================

FAQ
---

Q: Will the patched game run on non-turbo machines?
A: Yes, the patch implements a new timing routine that supports any CPU speed,
   including of course the standard 3.57MHz Z80A.

Q: I applied the patch and the resulting ROM doesn't work! What is wrong?
A: You're probably trying to apply the patch on a ROM with the incorrect
   checksum.

Q: Why there are IPS and XPC patches? Do I need to apply both?
A: Its the same patch in two different formats. You only need to use the format
   you think is more suitable to your needs. IPS files only support one single
   patch per file and need to be pre-applied, while XPC files support multiple
   different patches in a single file and can be used for on-the-fly patching.


==============================

I hope you enjoy these enhancements and fixes.


===========================================================================
	                     License
                           Terms of use
---------------------------------------------------------------------------

1) This patch is free (gratis) for non-commercial purposes. You can only run,
   make backup copies or distribute the patch under this strict condition.

2) You are only allowed distribute the patch files (online or on a removable
   media) under the following conditions:
   2.1) No commercial transaction of any kind is involved
   2.2) All the included files are distributed together inside the same
   compressed file.

3) If you want to use this patch for commercial purposes you MUST contact me
   first to negotiate the terms and conditions. Use the e-mail supplied at
   the beginning of this document for contacting me.

4) This software is provided free of charge for non-commercial purposes, and the
   author retains its copyright.

5) You cannot distribute ROMs with my patches applied on them.

6) This software is provided ‘as-is’, without any express or implied warranty.
   In no event will the author be held liable for any damages arising from the
   use of this software.

7) USE THIS SOFTWARE SOLELY AT YOUR OWN RISK.

